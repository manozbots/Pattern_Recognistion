This contains matlab codes to implement SINDy for Lorenz attractor.

1) Lorenz: defines differential equation.
2) PooData : Sets up library including non-linearities.
3) SINDY_Lorenz : Generates data, uses sparsifyDynamics to find sparse coefficients.
4) PoolDataLIST : List the identified coefficients. 